#include <glew.h>
#include <freeglut.h>
#include "glm/glm.hpp"
#include "glm/trigonometric.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "GLShader.cpp"
#include <iostream>
#include <fstream>
#include <regex>
#include <string>
#include <SOIL/SOIL.h>
#include "Affind3D.h"

GLuint Program;
GLint Unif_color;

GLShader shaderVBO;
GLShader shader;
GLuint VBO_vertex;
GLuint VBO_color;
GLuint VBO_indices;
GLuint VBO_Attrib_vertex;
GLuint VBO_Attrib_color;
GLuint VBO_Unif_matrix;
GLuint VBO_normal;
GLuint VBO_texture;
GLuint Attrib_vertex;
GLuint Attrib_color;
GLuint Unif_matrix;
GLuint texture_1;
GLShader toon_shader;
GLShader default_shader;
GLShader gachi_muchi_shader;
//monkey_smol.obj
//capsule1.obj
string filename = "monkey_smol.obj";

enum ShType
{
	def = 0,
	toon,
	gachi
};
ShType cur_type;
int indicies_count;

double rotate_x = 45;
double rotate_y = 45;
double rotate_z = 0;
void checkOpenGLerror()
{
	const GLubyte* kek;
	GLenum errCode;
	if ((errCode = glGetError()) != GL_NO_ERROR)
	{
		kek = gluErrorString(errCode);
		std::cout << kek << std::endl;
	}

}
void initVBO()
{
	//file

	setlocale(LC_ALL, "rus"); // ���������� ����������� ���������

	Point point(1, 2, 3);
	char buff[1000]; // ����� �������������� �������� ������������ �� ����� ������
	ifstream fin(filename); // ������� ���� ��� ������

	regex myregex;
	int mode = 0;

	Polyhedron polyhedron;


	while (!fin.eof())
	{
		fin.getline(buff, 1000); // ������� ������ �� �����
		string s = buff;
		if (s[0] == 'v')
		{
			if (s[1] == ' ')
			{
				myregex = regex("v (\-?\\d+,\\d+) (\-?\\d+,\\d+) (\-?\\d+,\\d+)");
				mode = 0;
			}
			else if (s[1] == 'n')
			{
				myregex = regex("vn (\-?\\d+,\\d+) (\-?\\d+,\\d+) (\-?\\d+,\\d+)");
				mode = 1;
			}
			else if (s[1] == 't')
			{
				myregex = regex("vt (\-?\\d+,\\d+) (\-?\\d+,\\d+)");
				mode = 2;
			}
		}
		else if (s[0] == 'f')
		{
			myregex = regex("f (\\d+/\\d+/\\d+) (\\d+/\\d+/\\d+) (\\d+/\\d+/\\d+)");
			mode = 3;
		}
		else
			continue;
		auto words_begin = sregex_iterator(s.begin(), s.end(), myregex);
		auto words_end = sregex_iterator();
		for (sregex_iterator i = words_begin; i != words_end; i++)
		{
			smatch match = *i;
			if (mode == 0)
			{
				Point p(stod(match[1]), stod(match[2]), stod(match[3]));
				polyhedron.pointList.push_back(p);
			}
			else if (mode == 1)
			{
				Point p(stod(match[1]), stod(match[2]), stod(match[3]));
				polyhedron.normalList.push_back(p);
			}
			else if (mode == 2)
			{
				Point2D p(stod(match[1]), stod(match[2]));
				polyhedron.texturePoint.push_back(p);
			}
			else if (mode == 3)
			{
				vector<tuple<int, int, int>> polygon = vector<tuple<int, int, int>>();
				for (int j = 1; j < match.size(); j++)
				{
					regex point = regex("(\\d+)/(\\d+)/(\\d+)");
					string s0 = match[j];
					auto matchpoint = sregex_iterator(s0.begin(), s0.end(), point);
					//smatch matchpoint = *pointm;
					polygon.push_back(make_tuple(stoi((*matchpoint)[1]) - 1, stoi((*matchpoint)[2]) - 1, stoi((*matchpoint)[3]) - 1));
				}
				polyhedron.polygons.push_back(polygon);
			}
		}
	}
	cout << polyhedron.polygons.size() << endl;
	GLint* indices = new int[polyhedron.polygons.size() * 3];
	GLint* indicesnorm = new int[polyhedron.polygons.size() * 3];
	GLint* indicestext = new int[polyhedron.polygons.size() * 3];
	int pointer = 0;
	for (int i = 0; i < polyhedron.polygons.size(); i++)
	{
		for (int j = 0; j < polyhedron.polygons[i].size(); j++)
		{
			indices[pointer] = get<0>(polyhedron.polygons[i][j]);
			indicestext[pointer] = get<1>(polyhedron.polygons[i][j]);
			indicesnorm[pointer] = get<2>(polyhedron.polygons[i][j]);
			++pointer;
		}
	}

	fin.close(); // ��������� ����

	vector<Point> okpoints = vector<Point>();
	vector<Point2D> oktextures = vector<Point2D>();
	vector<Point> oknormals = vector<Point>();

	for (int i = 0; i < polyhedron.polygons.size() * 3; i++)
	{
		okpoints.push_back(polyhedron.pointList[indices[i]]);
		oktextures.push_back(polyhedron.texturePoint[indicestext[i]]);
		oknormals.push_back(polyhedron.normalList[indicesnorm[i]]);
	}

	//file


	glGenBuffers(1, &VBO_vertex);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_vertex);
	/*glBufferData(GL_ARRAY_BUFFER, polyhedron.pointList.size()*sizeof(float)*3, &polyhedron.pointList[0],
		GL_STATIC_DRAW);*/
	glBufferData(GL_ARRAY_BUFFER, okpoints.size() * sizeof(float) * 3, &okpoints[0],
		GL_STATIC_DRAW);

	glGenBuffers(1, &VBO_normal);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_normal);
	//glBufferData(GL_ARRAY_BUFFER, polyhedron.normalList.size() * sizeof(float) * 3, &polyhedron.normalList[0], //todo
		//GL_STATIC_DRAW);
	glBufferData(GL_ARRAY_BUFFER, oknormals.size() * sizeof(float) * 3, &oknormals[0], //todo
		GL_STATIC_DRAW);
	
	glGenBuffers(1, &VBO_texture);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_texture);
	/*glBufferData(GL_ARRAY_BUFFER, polyhedron.texturePoint.size()*sizeof(float)*2, &polyhedron.texturePoint[0], 
		GL_STATIC_DRAW);*/

	glBufferData(GL_ARRAY_BUFFER, oktextures.size() * sizeof(float) * 2, &oktextures[0],
		GL_STATIC_DRAW);

	//glGenBuffers(1, &VBO_indices);
	//glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, VBO_indices);
	///*GLint indice[] = {
	//	0 , 4 , 5 , 0 , 5 , 1 ,
	//	1 , 5 , 6 , 1 , 6 , 2 ,
	//	2 , 6 , 7 , 2 , 7 , 3 ,
	//	3 , 7 , 4 , 3 , 4 , 0 ,
	//	4 , 7 , 6 , 4 , 6 , 5 ,
	//	3 , 0 , 1 , 3 , 1 , 2
	//};*/
	//indicies_count = pointer;
	//glBufferData(GL_ELEMENT_ARRAY_BUFFER, pointer * sizeof(GLint), indices,
	//	GL_STATIC_DRAW);
	indicies_count = pointer;
	checkOpenGLerror();
}

void freeVBO()
{
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	glDeleteBuffers(1, &VBO_vertex);
	glDeleteBuffers(1, &VBO_normal);
	glDeleteBuffers(1, &VBO_texture);
	glDeleteBuffers(1, &VBO_indices);
}

void initShader()
{
	const char* vertex_Source =
		"#version 330 core\n"
		"#define VERT_POSITION 0\n"
		"#define VERT_TEXCOORD 1\n"
		"#define VERT_NORMAL 2\n"
		"layout(location=VERT_POSITION) in vec3 position;\n"
		"layout(location=VERT_TEXCOORD) in vec2 texcoord;\n"
		"layout(location=VERT_NORMAL) in vec3 normal;\n"
		"uniform struct Transform{\n"
		"	mat4 model;\n"
		"	mat4 viewProjection;\n"
		"	mat4 normal;\n"
		"	vec3 viewPosition;\n"
		"} transform;\n"
		"uniform struct PointLight{\n"
		"	vec4 position;\n"
		"	vec4 ambient;\n"
		"	vec4 diffuse;\n"
		"	vec4 specular;\n"
		"	vec3 attenuation;\n"
		"} light;\n"
		"out struct Vertex{\n"
		"	vec2 texcoord;\n"
		"	vec3 normal;\n"
		"	vec3 lightDir;\n"
		"	vec3 viewDir;\n"
		"	float distance;\n"
		"} Vert;\n"
		"void main(void){\n"
		"	vec4 vertex = transform.model*vec4(position,1.0);\n"
		"	vec4 lightDir = light.position - vertex;\n"
		"	gl_Position = transform.viewProjection*vertex;\n"
		"	Vert.texcoord=texcoord;\n"///////////////////////////////
		"	vec4 kek = transform.normal * vec4(normal, 1);\n"
		"	Vert.normal= vec3(kek.x, kek.y, kek.z);\n"
		"	Vert.lightDir=vec3(lightDir);\n"
		"	Vert.viewDir=transform.viewPosition - vec3(vertex);\n"
		"	Vert.distance=length(lightDir);\n"
		"}\n";
	const char* fragment_Source =
		"#version 330 core\n"
		"#define FRAG_OUTPUT0 0\n"
		"layout(location=FRAG_OUTPUT0) out vec4 color;\n"
		"uniform struct PointLight{\n"
		"	vec4 position;\n"
		"	vec4 ambient;\n"
		"	vec4 diffuse;\n"
		"	vec4 specular;\n"
		"	vec3 attenuation;\n"
		"} light;\n"
		"uniform struct Material{\n"
		"	sampler2D texture;\n"
		"	vec4 ambient;\n"
		"	vec4 diffuse;\n"
		"	vec4 specular;\n"
		"	vec4 emission;\n"
		"	float shininess;\n"
		"} material;\n"
		"in struct Vertex {\n"
		"	vec2 texcoord;\n"
		"	vec3 normal;\n"
		"	vec3 lightDir;\n"
		"	vec3 viewDir;\n"
		"	float distance;\n"
		"} Vert;\n"
		"void main(void){\n"
		"	vec3 normal = normalize(Vert.normal);\n"
		"	vec3 lightDir = normalize(Vert.lightDir);\n"
		"	vec3 viewDir = normalize(Vert.viewDir);\n"
		"	float attenuation=1.0/(light.attenuation[0]+\n"
		"	light.attenuation[1]*Vert.distance+\n"
		"	light.attenuation[2]*Vert.distance*Vert.distance);\n"
		"	color=material.emission;\n"
		"	color +=material.ambient*light.ambient*attenuation;\n"
		"	float Ndot=max(dot(normal,lightDir),0.0);\n"
		"	color += material.diffuse*light.diffuse*Ndot*attenuation; \n"
		"	vec3 h = normalize(lightDir + viewDir);\n"	
		"	float RdotVpow = max(pow(dot(normal, h), material.shininess), 0.0);\n"
		//"	color+=material.specular*light.specular*RdotVpow*attenuation;\n"
		//"	color*=vec4(1, 0, 0, 1);\n"
		//"color*= vec4(Vert.texcoord, 0,1);\n"
		"  color*=texture(material.texture,Vert.texcoord);\n"///////////////////////////////
		"}\n";

	const char* toon_fragment_Source = 
		"#version 330 core\n"
		"#define FRAG_OUTPUT0 0\n"
		"layout(location=FRAG_OUTPUT0) out vec4 color;\n"
		"uniform struct PointLight{\n"
		"	vec4 position;\n"
		"	vec4 ambient;\n"
		"	vec4 diffuse;\n"
		"	vec4 specular;\n"
		"	vec3 attenuation;\n"
		"} light;\n"
		"uniform struct Material{\n"
		"	sampler2D texture;\n"
		"	vec4 ambient;\n"
		"	vec4 diffuse;\n"
		"	vec4 specular;\n"
		"	vec4 emission;\n"
		"	float shininess;\n"
		"} material;\n"
		"in struct Vertex {\n"
		"	vec2 texcoord;\n"
		"	vec3 normal;\n"
		"	vec3 lightDir;\n"
		"	vec3 viewDir;\n"
		"	float distance;\n"
		"} Vert;\n"
		"void main(void){\n"
		"	vec3 normal = normalize(Vert.normal);\n"
		"	vec3 lightDir = normalize(Vert.lightDir);\n"
		"	vec3 viewDir = normalize(Vert.viewDir);\n"
		"	float diff = 0.2 + max(dot(normal, lightDir), 0.0);\n"
		"	if (diff < 0.4)\n"
		"		color = material.diffuse * 0.3f;\n"
		"	else if (diff < 0.7)\n"
		"		color = material.diffuse;\n"
		"	else color = material.diffuse * 1.3f;\n"
		"	color*=vec4(1, 0, 0, 1);\n"
		//"color*=texture(material.texture,Vert.texcoord);\n"
		"}\n";

	const char* gachi_fragment_Source =
		"#version 330 core\n"
		"#define FRAG_OUTPUT0 0\n"
		"layout(location=FRAG_OUTPUT0) out vec4 color;\n"
		"in vec4 coolColor;\n"
		"in vec4 warmColor;\n"
		"uniform struct PointLight{\n"
		"	vec4 position;\n"
		"	vec4 ambient;\n"
		"	vec4 diffuse;\n"
		"	vec4 specular;\n"
		"	vec3 attenuation;\n"
		"} light;\n"
		"uniform struct Material{\n"
		"	sampler2D texture;\n"
		"	vec4 ambient;\n"
		"	vec4 diffuse;\n"
		"	float diffuseCool;\n"
		"	float diffuseWarm;\n"
		"	vec4 specular;\n"
		"	vec4 emission;\n"
		"	float shininess;\n"
		"} material;\n"
		"in struct Vertex {\n"
		"	vec2 texcoord;\n"
		"	vec3 normal;\n"
		"	vec3 lightDir;\n"
		"	vec3 viewDir;\n"
		"	float distance;\n"
		"} Vert;\n"
		"void main(void){\n"
		"	vec3 normal = normalize(Vert.normal);\n"
		"	vec3 lightDir = normalize(Vert.lightDir);\n"
		"	vec3 viewDir = normalize(Vert.viewDir);\n"
		"	vec3 reflectDir = normalize(reflect(-lightDir, normal));\n" // check it again
		"	vec4 coolColor = vec4(0, 0, 0.7f, 1);\n"
		"	vec4 warmColor = vec4(0.7f, 0, 0, 1);\n"
		"	color = vec4(0, 0.7f, 0, 1);\n"
		"	float Ndot = max(dot(normal,lightDir),0.0);\n"
		"	vec4 kCoolColor = coolColor + material.diffuseCool * material.diffuse;\n"
		"	vec3 kCool = vec3(min(kCoolColor.x, 1), min(kCoolColor.y, 1), min(kCoolColor.z, 1));\n"
		"	vec4 kWarmColor = warmColor + material.diffuseWarm * material.diffuse;\n"
		"	vec3 kWarm = vec3(min(kWarmColor.x, 1), min(kWarmColor.y, 1), min(kWarmColor.z, 1));\n"
		"	vec3 kFinal = mix(kCool, kWarm, Ndot);\n"
		//"	float spec = pow(max(dot(reflectDir, viewDir), 0.0), 1000.0);\n"
		"	vec3 finalColor = kFinal;\n"
		"	color = vec4(min(finalColor.x, 1.0), min(finalColor.y, 1.0), min(finalColor.z, 1.0), 1.0);\n"
		//"color*=texture(material.texture,Vert.texcoord);\n"
		"}\n";
	
	default_shader = GLShader();
	default_shader.load(vertex_Source, fragment_Source);

	toon_shader = GLShader();
	toon_shader.load(vertex_Source, toon_fragment_Source);
	auto kek = glm::vec3(0, 0, 0) + 3.0f;
	gachi_muchi_shader = GLShader();
	gachi_muchi_shader.load(vertex_Source, gachi_fragment_Source);
	
	initVBO();
}
void resizeWindow(int width, int height)
{
	glViewport(0, 0, width, height);
}

void render2()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glm::mat4 Projection = glm::perspective(glm::radians(45.0f), 4.0f / 3.0f, 0.1f, 100.0f);
	glm::mat4 View = glm::lookAt(glm::vec3(4, 3, 3), glm::vec3(0, 0, 0), glm::vec3(0, 1, 0));
	glm::mat4 Model = glm::mat4(1.0f);
	Model = glm::rotate(Model, glm::radians((float)rotate_x), glm::vec3(1, 0, 0));
	Model = glm::rotate(Model, glm::radians((float)rotate_y), glm::vec3(0, 1, 0));
	Model = glm::rotate(Model, glm::radians((float)rotate_z), glm::vec3(0, 0, 1));
	glm::mat4 MVP = Projection * View * Model;
	glm::mat4 normalMatrix = glm::transpose(glm::inverse(View * Model));
	glm::mat4 viewProjection = Projection * View;
	GLfloat viewPos[] = { 4, 3, 3};
	GLfloat lightPos[] = { 0, 4, 0, 1};

	GLfloat attenuation[] = { 0.5f, 0.5f, 0.5f };
	GLfloat ambient[] = { 1, 1, 1 , 1};
	GLfloat diffuse[] = { 1, 1, 1, 1 };
	GLfloat specular[] = { 1, 1, 1, 1 };

	GLfloat ambient_mat[] = { 1.5, 1.5, 1.5, 1 };
	GLfloat diffuse_mat[] = { 10, 10, 10, 1 };
	GLfloat specular_mat[] = { 0.1f, 0.1f, 0.1f, 1 };
	GLfloat emission_mat[] = { 0, 0, 0, 1 };
	GLfloat shininess = 1;

	GLfloat toon_diffuse_mat[] = { 0.5f, 0.8, 0.8, 1 };

	GLfloat diffuseCool = 0.8f;
	GLfloat diffuseWarm = 0.4f;
	GLfloat gachi_diffuse[] = { 0.2f, 0.6f, 0.2f, 1 };
	GLfloat coolColor[] = { 0, 0 , 0.2f, 1 };
	GLfloat warmColor[] = { 0.2f, 0 , 0, 1 };
	switch (cur_type)
	{
	case def:
		shader = default_shader;
		break;
	case toon:
		shader = toon_shader;
		break;
	case gachi:
		shader = gachi_muchi_shader;
		break;
	default:
		break;
	}
	shader.use();

	glUniformMatrix4fv(shader.getUniformLocation("transform.model"), 1, GL_FALSE, &Model[0][0]);
	glUniformMatrix4fv(shader.getUniformLocation("transform.viewProjection"), 1, GL_FALSE, &viewProjection[0][0]);
	glUniformMatrix4fv(shader.getUniformLocation("transform.normal"), 1, GL_FALSE, &normalMatrix[0][0]);
	glUniform3fv(shader.getUniformLocation("transform.viewPosition"), 1, viewPos);
	
	glUniform4fv(shader.getUniformLocation("light.position"), 1, lightPos);
	glUniform4fv(shader.getUniformLocation("light.ambient"), 1, ambient);
	glUniform4fv(shader.getUniformLocation("light.diffuse"), 1, diffuse);
	glUniform4fv(shader.getUniformLocation("light.specular"), 1, specular);
	glUniform3fv(shader.getUniformLocation("light.attenuation"), 1, attenuation);
	glUniform1f(shader.getUniformLocation("light.shininess"), shininess);

	glUniform4fv(shader.getUniformLocation("material.ambient"), 1, ambient_mat);
	switch (cur_type)
	{
		case def:
			glUniform4fv(shader.getUniformLocation("material.diffuse"), 1, diffuse_mat);
			break;
		case toon:
			glUniform4fv(shader.getUniformLocation("material.diffuse"), 1, toon_diffuse_mat);
			break;
		case gachi:
			glUniform4fv(shader.getUniformLocation("material.diffuse"), 1, gachi_diffuse);
			glUniform1f(shader.getUniformLocation("material.diffuseCool"), diffuseCool);
			glUniform1f(shader.getUniformLocation("material.diffuseWarm"), diffuseWarm);
			glUniform4fv(shader.getUniformLocation("coolColor"), 1, coolColor);
			glUniform4fv(shader.getUniformLocation("warmColor"), 1, warmColor);
			break;
		default:
			break;
	}
	
		
	glUniform4fv(shader.getUniformLocation("material.specular"), 1, specular_mat);
	glUniform4fv(shader.getUniformLocation("material.emission"), 1, emission_mat);
	glUniform1f(shader.getUniformLocation("material.shininess"), shininess);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texture_1);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glUniform1i(shader.getUniformLocation("material.texture"), 0);

	glEnableVertexAttribArray(1);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_texture);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, 0);

	//glUniform1i(glGetUniformLocation(shader, "material.texture"), 0);

	//glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, VBO_indices);

	glEnableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_vertex);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);

	glEnableVertexAttribArray(2);
	glBindBuffer(GL_ARRAY_BUFFER, VBO_normal);
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 0, 0);

	//glDrawElements(GL_TRIANGLES, indicies_count, GL_UNSIGNED_INT, 0);
	glDrawArrays(GL_TRIANGLES, 0, indicies_count);

	glDisableVertexAttribArray(0);
	glDisableVertexAttribArray(1);
	glDisableVertexAttribArray(2);

	shader.off();
	checkOpenGLerror();
	glFlush();
	glutSwapBuffers();
}
void specialKeys(int key, int x, int y) {

	switch (key) {
	case GLUT_KEY_UP: rotate_x += 5; break;
	case GLUT_KEY_DOWN: rotate_x -= 5; break;
	case GLUT_KEY_RIGHT: rotate_y += 5; break;
	case GLUT_KEY_LEFT: rotate_y -= 5; break;
	case GLUT_KEY_PAGE_UP: rotate_z += 5; break;
	case GLUT_KEY_PAGE_DOWN: rotate_z -= 5; break;
	case GLUT_KEY_F5: cur_type = cur_type == gachi ? def : (ShType)(cur_type + 1);
	}
	glutPostRedisplay();

}
int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_RGBA | GLUT_ALPHA | GLUT_DOUBLE);
	glutInitWindowSize(600, 600);
	glutCreateWindow("Simple shaders");
	glClearColor(0, 0, 0, 0);
	GLenum glew_status = glewInit();
	if (GLEW_OK != glew_status)
	{
		std::cout << "Error: " << glewGetErrorString(glew_status) << "\n";
		return 1;
	}
	if (!GLEW_VERSION_2_0)
	{
		std::cout << "No support for OpenGL 2.0 found\n";
		return 1;
	}
	cur_type = def;
	glEnable(GL_DEPTH_TEST);
	string texture_path = "capsulekek.jpg";
	texture_1 = SOIL_load_OGL_texture(texture_path.c_str(), SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);
	initShader();
	glutReshapeFunc(resizeWindow);
	glutDisplayFunc(render2);
	glutSpecialFunc(specialKeys);
	glutMainLoop();
	freeVBO();
}